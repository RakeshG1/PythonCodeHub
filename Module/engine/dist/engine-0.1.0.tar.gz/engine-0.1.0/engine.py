def start_engine():
    print("Engine Started")

